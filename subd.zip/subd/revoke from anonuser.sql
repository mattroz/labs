
revoke all on *.* from anonuser;
flush privileges;