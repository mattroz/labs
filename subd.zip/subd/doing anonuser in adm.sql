grant all on *.* to anonuser;
flush privileges;

